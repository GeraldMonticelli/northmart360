dev_public_ips     = ["94.224.161.87", "94.224.220.97", "81.165.253.149"]
sql_admin_login    = "northmartadmin"
sql_admin_password = "TU23mong"

environment                            = "dev"
resource_group_name                    = "rg-dp750"
storage_account_name                   = "stnorthmartdev"
key_vault_name                         = "kv-northmart-gmkng"
workspace_name                         = "adb-dp750"
databricks_managed_resource_group_name = "databricks-rg-adb-dp750-1ejtwyuys0j4z"