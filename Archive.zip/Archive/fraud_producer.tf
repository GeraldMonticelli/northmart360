resource "azurerm_subnet" "fraud_producer" {
  name                 = "snet-fraud-producer"
  resource_group_name  = local.resource_group_name
  virtual_network_name = local.vnet_name
  address_prefixes     = ["10.20.3.0/24"]
}

resource "azurerm_network_security_group" "fraud_producer" {
  name                = "nsg-fraud-producer"
  location            = var.location
  resource_group_name = local.resource_group_name

  security_rule {
    name                   = "Allow-SSH-From-My-IP"
    priority               = 100
    direction              = "Inbound"
    access                 = "Allow"
    protocol               = "Tcp"
    source_port_range      = "*"
    destination_port_range = "22"
    source_address_prefixes = [
      for ip in var.dev_public_ips : "${ip}/32"
    ]
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "fraud_producer" {
  subnet_id                 = azurerm_subnet.fraud_producer.id
  network_security_group_id = azurerm_network_security_group.fraud_producer.id
}

resource "azurerm_public_ip" "fraud_producer" {
  name                = "pip-fraud-producer"
  location            = var.location
  resource_group_name = local.resource_group_name

  allocation_method = "Static"
  sku               = "Standard"
}


resource "azurerm_network_interface" "fraud_producer" {
  # checkov:skip=CKV_AZURE_119:Public IP temporarily required for fraud producer lab administration
  name                = "nic-fraud-producer"
  location            = var.location
  resource_group_name = local.resource_group_name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = azurerm_subnet.fraud_producer.id
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.fraud_producer.id
  }
}


resource "azurerm_linux_virtual_machine" "fraud_producer" {
  # checkov:skip=CKV_AZURE_50:VM extensions accepted for fraud producer learning workload
  name                = "vm-fraud-producer"
  resource_group_name = local.resource_group_name
  location            = var.location

  size = "Standard_D2s_v6"

  admin_username = "azureuser"

  network_interface_ids = [
    azurerm_network_interface.fraud_producer.id
  ]

  identity {
    type = "SystemAssigned"
  }

  admin_ssh_key {
    username   = "azureuser"
    public_key = var.fraud_producer_ssh_public_key
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }
}
