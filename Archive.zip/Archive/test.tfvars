environment          = "test"
resource_group_name  = "rg-northmart-test"
storage_account_name = "stnorthmarttest"
key_vault_name       = "kv-northmart-test"
workspace_name       = "adb-northmart-test"

dev_public_ips                         = ["94.224.161.87", "81.165.253.149"]
sql_admin_login                        = "northmartadmin"
sql_admin_password                     = "TU23mong"
databricks_managed_resource_group_name = "databricks-rg-adb-northmart-test"